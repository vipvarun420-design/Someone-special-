// ❤️ Floating Hearts
const heartsContainer = document.createElement("div");
heartsContainer.classList.add("hearts");
document.body.appendChild(heartsContainer);

function createHeart() {
  const heart = document.createElement("div");
  heart.classList.add("heart");
  heart.innerText = "💗";
  heart.style.left = Math.random() * 100 + "vw";
  heart.style.fontSize = Math.random() * 20 + 20 + "px";
  heart.style.animationDuration = Math.random() * 3 + 4 + "s";
  heartsContainer.appendChild(heart);
  setTimeout(() => heart.remove(), 7000);
}
setInterval(createHeart, 800);

// 💌 Form Submit
document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("wishForm");
  const output = document.getElementById("output");

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const name = document.getElementById("name").value;
    const message = document.getElementById("message").value;

    output.innerHTML = `🎇 Thank you <strong>${name}</strong> 💖<br> Your message: <em>${message}</em>`;
    form.reset();
  });
});

// 🎆 Fireworks on Click
function createFirework(x, y) {
  const firework = document.createElement("div");
  firework.classList.add("firework");
  firework.style.left = x + "px";
  firework.style.top = y + "px";
  document.body.appendChild(firework);

  for (let i = 0; i < 20; i++) {
    const spark = document.createElement("span");
    spark.classList.add("spark");
    spark.style.setProperty("--x", (Math.random() - 0.5) * 300 + "px");
    spark.style.setProperty("--y", (Math.random() - 0.5) * 300 + "px");
    firework.appendChild(spark);
  }

  setTimeout(() => firework.remove(), 2000);
}
document.addEventListener("click", (e) => createFirework(e.pageX, e.pageY));

document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("loveForm");
  const output = document.getElementById("output");

  if (form) {
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      const name = document.getElementById("name").value;
      const wish = document.getElementById("wish").value;

      output.innerHTML = `
        <div class="wish-card">
          <h3>💌 ${name} ka message 💌</h3>
          <p>${wish}</p>
        </div>
      `;

      form.reset();
    });
  }
});